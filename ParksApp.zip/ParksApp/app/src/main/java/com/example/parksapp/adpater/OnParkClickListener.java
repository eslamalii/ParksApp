package com.example.parksapp.adpater;

import com.example.parksapp.model.Park;

public interface OnParkClickListener {
    void onParkClicked(Park park);
}
