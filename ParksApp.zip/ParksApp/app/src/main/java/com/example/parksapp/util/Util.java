package com.example.parksapp.util;

public class Util {
    public static final String PARKS_URL = "https://developer.nps.gov/api/v1/parks?stateCode=wa&api_key=pAhzDtzmv7mcC5gbcwnKxISisMkJkFYh6OsQtr4x";
}
